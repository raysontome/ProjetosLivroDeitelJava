import javax.swing.JOptionPane;

public class CaixadeDialogo {

	public static void main(String[] args) {

		String name = JOptionPane.showInputDialog("Ola usuario! Qual o seu nome?");

		String message = String.format("Bem-vindo!", name);

		JOptionPane.showMessageDialog(null, message);
	}
}