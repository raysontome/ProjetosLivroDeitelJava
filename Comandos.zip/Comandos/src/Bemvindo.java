public class Bemvindo {
	public static void main(String args[]) {
		System.out.println("Welcome\nto\nJava\nProgramming! ");
	}
}

// Formatar código fonte: Cmd + Shift + F
// Organizar importações: Cmd + Shift + O
// Renomear refatorando: Cmd + Option + R
// Excluir linha de código: Cmd + D
// Mover linhas pelo código-fonte: Option + Seta Up/Down
// Corrigir código rapidamente: Cmd + 1
// Listar todos os atalhos do Eclipse: Cmd + Shift + L
// Operacoes java: + (soma), - (subtracao), * (multiplicacao), / (divisao), %
// (resto)